Arquivo zip gerado em: 12/06/2017 09:28:17 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Convolução de Imagens + KNN